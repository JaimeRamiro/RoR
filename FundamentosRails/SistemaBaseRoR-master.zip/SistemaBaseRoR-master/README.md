# README
Clone el proyecto 
* git clone https://github.com/learsixela/SistemaBaseRoR.git sistemabase
ingrese a la carpeta sistemabase
* cd sistemabase

Proceso de instalación.
* asegurese de tener instalado ruby 3.0.0 y rails 6.1.4 y sqlite3
* rails -v
* ruby -v
* sqlite3 --version

En la terminal, dentro de sistemabase, ejecutar en orden los siguientes pasos:

* rails webpacker:install
* bundle install
* rails db:drop
* rails db:migrate
* rails s -b 0.0.0.0

Visite la pagina http://localhost:3000/

Sientase libre de usar a su libre alcance.
